const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const { prefix } = require('./config.json');
const settings = require('./configViolator.json');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.commands = new Collection();

// Chargement des commandes
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.name, command);
}

client.once('ready', () => {
  console.log(`🔥 Violator Supreme prêt à écraser le serveur.`);
});

// Ecouteur unique
client.on('messageCreate', async message => {
  if (message.author.bot) return;

  // Antispam intégré
  const antiSpam = require('./utils/antispam');
  await antiSpam.execute(message);

  // Commandes
  if (!message.content.startsWith(prefix)) return;
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();
  const command = client.commands.get(commandName);
  if (!command) return;

  try {
    await command.execute(message, args);
  } catch (err) {
    console.error("❌ Erreur :", err);
    message.reply("💥 Violator a explosé. Trop de puissance.");
  }
});

client.login(process.env.TOKEN);
